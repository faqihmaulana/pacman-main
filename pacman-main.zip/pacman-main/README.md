# pacman

This is a version of pacman created in pure javascript using a canvas without any game frameworks

Checkout the full tutorial here https://www.youtube.com/watch?v=Tk48dQCdQ3E&ab_channel=CodingWithAdam
